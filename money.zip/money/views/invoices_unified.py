from datetime import date

from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.paginator import Paginator
from django.shortcuts import render
from django.views import View

from ..models import InvoiceV2, Client
from ..unified_invoices import (
    load_v2_invoices,
    load_legacy_model_invoices,
    load_legacy_files,
)


class InvoiceUnifiedListView(LoginRequiredMixin, View):
    """
    Unified invoice list that shows:
      - InvoiceV2 rows
      - Legacy DB invoices (old Invoice model)
      - Legacy PDF-only invoices

    It reuses the existing invoice_v2_list.html template and preserves:
      - Status filter
      - Year filter
      - Client filter
      - Pagination
    """

    template_name = "money/invoices/invoice_v2_list.html"
    paginate_by = 20

    def _get_filters(self, request):
        status = request.GET.get("status") or ""
        year = request.GET.get("year") or ""
        client_id = request.GET.get("client") or ""
        return status, year, client_id

    def get(self, request, *args, **kwargs):
        status, year_str, client_str = self._get_filters(request)

        # 1) Load all rows from the three sources
        rows = []
        rows.extend(load_v2_invoices(request))
        rows.extend(load_legacy_model_invoices(request))
        rows.extend(load_legacy_files(request))

        # 2) Apply filters in Python over the unified rows

        # Status filter (only rows that carry a matching status)
        if status:
            rows = [r for r in rows if (r.status == status)]

        # Year filter (match on issue_date.year)
        if year_str:
            try:
                year_int = int(year_str)
            except ValueError:
                year_int = None

            if year_int:
                rows = [
                    r for r in rows
                    if (r.issue_date and r.issue_date.year == year_int)
                ]

        # Client filter (we only know client_name in the row; we map the id to name)
        selected_client = None
        if client_str:
            try:
                cid = int(client_str)
                selected_client = Client.objects.filter(pk=cid).first()
            except ValueError:
                selected_client = None

            if selected_client:
                target_name = selected_client.business or str(selected_client)
                rows = [
                    r for r in rows
                    if r.client_name == target_name
                ]

        # 3) Sort by date desc, fallback to invoice_number
        rows.sort(
            key=lambda r: (
                r.issue_date or date.min,
                r.invoice_number,
            ),
            reverse=True,
        )

        # 4) Pagination over the unified list
        paginator = Paginator(rows, self.paginate_by)
        page_number = request.GET.get("page")
        page_obj = paginator.get_page(page_number)

        # 5) Build filter context (years + clients + selected filters)
        years_qs = (
            InvoiceV2.objects
            .order_by()
            .values_list("date__year", flat=True)
            .distinct()
        )
        years = sorted(set(y for y in years_qs if y))

        clients = Client.objects.all().order_by("business")

        context = {
            # core listing
            "invoices": page_obj.object_list,
            "page_obj": page_obj,
            "paginator": paginator,
            "is_paginated": page_obj.has_other_pages(),

            # filters
            "status_choices": InvoiceV2.STATUS_CHOICES,
            "selected_status": status,
            "selected_year": year_str,
            "selected_client": client_str,
            "years": years,
            "clients": clients,
        }

        return render(request, self.template_name, context)
