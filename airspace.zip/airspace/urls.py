from django.urls import path

from .views import *

app_name = "airspace"

urlpatterns = [
    path("waiver/helper/", airspace_waiver, name="waiver"),
    path("waiver/form/", airspace_waiver_form, name="waiver_form"),
    path("waiver/<int:pk>/conops/", waiver_conops_view, name="waiver_conops"),
    path("conops/", ConopsListView.as_view(), name="conops_list"),
    path("waivers/", WaiverListView.as_view(), name="waiver_list"),
    path("waiver/<int:pk>/edit/", airspace_waiver_edit, name="waiver_edit"),
    path("waiver/<int:pk>/conops/", waiver_conops_view, name="waiver_conops"),
 


]
