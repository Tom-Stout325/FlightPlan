from django.urls import path
from .views import (
    AirspacePortalView,
    waiver_wizard_new,
    waiver_wizard_edit,
    
    
    airspace_waiver_form,
    waiver_conops_view,
    ConopsListView,
    WaiverListView,
    airspace_waiver,
    AirspaceWaiverDraftWizard,
    WaiverConopsSummaryView,
    
)

app_name = "airspace"

urlpatterns = [
    path("", AirspacePortalView.as_view(), name="portal_home"),
    
    path("waiver/wizard/new/", waiver_wizard_new, name="waiver_wizard_new"),
    
    path("waiver/<int:pk>/edit/", waiver_wizard_edit, name="waiver_edit"),
    
    path("waivers/", WaiverListView.as_view(), name="waiver_list"),
    
    
    
    
    
    path("waiver/helper/", airspace_waiver, name="waiver"),
    
    path("waiver/draft/new/", AirspaceWaiverDraftWizard.as_view(), name="waiver_draft_new",),
    
    path("waiver/form/", airspace_waiver_form, name="waiver_form"),
    
    path("waiver/<int:pk>/conops/", waiver_conops_view, name="waiver_conops"),
    
    path("conops/", ConopsListView.as_view(), name="conops_list"),
    
    path("waiver/conops-summary/", WaiverConopsSummaryView.as_view(), name="waiver_conops_summary", ),
    

    
    
    
]
