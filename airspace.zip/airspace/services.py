from __future__ import annotations

from django.conf import settings
from openai import OpenAI

from .models import AirspaceWaiver


def get_openai_client() -> OpenAI:
    """
    Return a configured OpenAI client.

    Raises a clear error if the API key is missing so you don't
    get mysterious 401s in production.
    """
    api_key = getattr(settings, "OPENAI_API_KEY", None)
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY is not set in settings / environment. "
            "Add it to your .env and settings before calling OpenAI."
        )
    return OpenAI(api_key=api_key)




def build_conops_prompt(waiver: AirspaceWaiver) -> str:
    """
    Build a highly structured FAA-style CONOPS prompt with:
    - FAA waiver guidance phrasing
    - Clear outline matching FAA expectations
    - Soft validation of missing waiver fields
    """

    # Detect missing fields and warn GPT (helps avoid hallucinated values)
    missing = []
    FIELD_MAP = {
        "operation_title": "Operation Title",
        "proposed_location": "Proposed Location",
        "max_agl": "Maximum Altitude (AGL)",
        "lat_decimal": "Latitude",
        "lon_decimal": "Longitude",
        "nearest_airport": "Nearest Airport",
        "airspace_class": "Airspace Class",
        "short_description": "Short Operational Description",
    }

    for attr, label in FIELD_MAP.items():
        if not getattr(waiver, attr):
            missing.append(label)

    missing_note = (
        "The following required fields were NOT provided and must NOT be invented. "
        "Instead, clearly mark them as '[Missing Information]': "
        + ", ".join(missing)
        if missing
        else "All required fields were provided."
    )

    timeframe = waiver.get_timeframe_display()
    frequency = waiver.get_frequency_display()
    airspace_class = waiver.get_airspace_class_display()

    related = (
        f"Yes – {waiver.related_waiver_details}"
        if waiver.has_related_waiver
        else "None."
    )

    return f"""
You are an FAA Part 107 waiver and airspace specialist. 
Write a complete, FAA-style Concept of Operations (CONOPS) suitable for inclusion in an FAA DroneZone waiver application. 
Follow the FAA's **Waiver Safety Explanation Guideline (WSEG)** structure and safety-focused expectations.

Your CONOPS **must**:

- Use clear, formal aviation language appropriate for the FAA.
- Follow FAA operational-risk-based structure.
- Avoid inventing any details not provided. If required data is missing, say: **"[Missing Information]"**.
- Be written in short, well-structured paragraphs — no bullets in final output.
- Present mitigations, procedures, and safety rationales consistent with FAA advisory circulars.

---------------------------------------------------------------------
### Missing or incomplete waiver fields:
{missing_note}
---------------------------------------------------------------------

### FAA-Required CONOPS Structure  
Use **all** sections below, modeled closely after FAA guidance:

**1. Overview of the Proposed Operation**  
State the purpose, type of operation, aircraft category, and why this operation requires FAA review.

**2. Operating Environment & Airspace**  
Describe the geographical area, environment, airspace classification, obstacles, nearby airports, and operational radius.

**3. Aircraft Information & Safety Features**  
Include aircraft type, weight, performance limitations, Remote ID, GPS, geofencing, obstacle sensing, parachute systems (if applicable), lost-link behavior, manufacturer safety features.

**4. Crew Qualifications & Responsibilities**  
Describe PIC qualifications (Part 107 certification, flight hours), VO roles, crew communications, required briefings, and crew-to-crew procedures.

**5. Normal Operations Procedures**  
Describe launch/recovery areas, airspace monitoring, safety cones/barriers, preflight inspections, checklists, communications, and public safety protections.

**6. Abnormal Procedures & Emergency Mitigations**  
Detail lost-link actions, fly-away plan, emergency landing areas, weather minima, risk buffers, NOTAM review (if applicable), and immediate hazard responses.

**7. Coordination with ATC / Airport Management**  
Describe procedures for prior notification, on-site communications, maintaining situational awareness, holding procedures, and complying with ATC instructions (if required).

**8. Hazard Identification & Risk Mitigation Strategy**  
Provide a safety-based justification of mitigations, referencing FAA risk-based criteria:  
- Ground risk mitigations  
- Air risk mitigations  
- Crew mitigations  
- Equipment mitigations  

**9. Compliance with 14 CFR Part 107 & Waiver Conditions**  
Explain how the operator ensures compliance with Part 107 and any waiver-specific conditions.

---------------------------------------------------------------------
### Waiver Data Provided by Operator

Operation Title: {waiver.operation_title or "[Missing Information]"}

Dates of Operation: {waiver.start_date} to {waiver.end_date}  
Timeframe: {timeframe or "[Missing]"}  
Frequency: {frequency or "[Missing]"}  
Local Time Zone: {waiver.local_timezone or "[Missing]"}

Location Description:  
{waiver.proposed_location or "[Missing]"}

Maximum Altitude (AGL): {waiver.max_agl or "[Missing]"}  
Airspace Class: {airspace_class or "[Missing]"}  
Radius: {waiver.radius_nm or "[Missing]"} NM  
Nearest Airport: {waiver.nearest_airport or "[Missing]"}

Coordinates (Decimal):  
Latitude: {waiver.lat_decimal or "[Missing]"}  
Longitude: {waiver.lon_decimal or "[Missing]"}

Operator’s Short Operational Description:  
{waiver.short_description or "[Missing]"}

Related Existing Waivers: {related}

---------------------------------------------------------------------

### FINAL INSTRUCTION  
Now write a **complete, polished FAA-style CONOPS** using the structure above.  
Do NOT use bullet points in the final result — only well-structured paragraphs.  
Do NOT fabricate missing information — explicitly mark as “[Missing Information]”.
    """.strip()


def generate_conops_text(waiver: AirspaceWaiver, *, model: str = "gpt-5-mini") -> str:
    """
    Call OpenAI to generate a CONOPS text for the given waiver.

    Returns the plain text body. Caller is responsible for saving it.
    """
    client = get_openai_client()
    prompt_text = build_conops_prompt(waiver)

    response = client.responses.create(
        model=model,
        input=prompt_text,
        max_output_tokens=6000,
        # NOTE: 'temperature' is not supported for this model with Responses API,
        # so we omit it to avoid 400 BadRequestError.
    )

    return response.output_text
