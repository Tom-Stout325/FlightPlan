# airspace/views.py
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.generic import ListView

from .forms import AirspaceWaiverForm
from .models import AirspaceWaiver
from .services import generate_conops_text


@login_required
def airspace_waiver(request):
    """
    Simple landing/helper page for the airspace waiver helper.
    """
    return render(request, "airspace/airspace_waiver.html")


@login_required
def airspace_waiver_form(request):
    """
    Create a new AirspaceWaiver draft.
    After saving, redirect to the CONOPS page for that waiver.
    """
    if request.method == "POST":
        form = AirspaceWaiverForm(request.POST)
        if form.is_valid():
            waiver = form.save(commit=False)
            waiver.user = request.user
            waiver.save()  # save() computes decimal coords

            messages.success(
                request,
                "Waiver draft saved. You can now generate a CONOPS from this data.",
            )
            return redirect("airspace:waiver_conops", pk=waiver.pk)
        else:
            messages.error(request, "Please correct the errors below.")
            lat_decimal = None
            lon_decimal = None
    else:
        form = AirspaceWaiverForm()
        lat_decimal = None
        lon_decimal = None

    context = {
        "form": form,
        "lat_decimal": lat_decimal,
        "lon_decimal": lon_decimal,
        "is_edit": False,
    }
    return render(request, "airspace/waiver_form.html", context)


@login_required
def airspace_waiver_edit(request, pk):
    """
    Edit an existing AirspaceWaiver.
    Reuses the same waiver_form.html template, but passes the instance.
    """
    waiver = get_object_or_404(AirspaceWaiver, pk=pk, user=request.user)

    if request.method == "POST":
        form = AirspaceWaiverForm(request.POST, instance=waiver)
        if form.is_valid():
            waiver = form.save()  # coordinates updated in model.save()
            messages.success(request, "Waiver updated successfully.")
            # You can send them back to CONOPS or stay on the form; for now, stay here.
            return redirect("airspace:waiver_edit", pk=waiver.pk)
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = AirspaceWaiverForm(instance=waiver)

    context = {
        "form": form,
        "lat_decimal": waiver.lat_decimal,
        "lon_decimal": waiver.lon_decimal,
        "waiver": waiver,
        "is_edit": True,
    }
    return render(request, "airspace/waiver_form.html", context)


@login_required
def waiver_conops_view(request, pk):
    """
    Display a single waiver and allow generating / regenerating CONOPS text.
    """
    waiver = get_object_or_404(AirspaceWaiver, pk=pk, user=request.user)

    if request.method == "POST":
        try:
            conops = generate_conops_text(waiver)
            waiver.conops_text = conops
            waiver.conops_generated_at = timezone.now()
            waiver.save(update_fields=["conops_text", "conops_generated_at"])
            messages.success(request, "CONOPS generated successfully.")
            return redirect("airspace:waiver_conops", pk=waiver.pk)
        except Exception as e:
            messages.error(
                request,
                f"Something went wrong while generating the CONOPS: {e}",
            )

    context = {
        "waiver": waiver,
    }
    return render(request, "airspace/waiver_conops.html", context)


class ConopsListView(LoginRequiredMixin, ListView):
    """
    Shows only waivers that already have CONOPS text.
    """
    model = AirspaceWaiver
    template_name = "airspace/conops_list.html"
    context_object_name = "waivers"
    paginate_by = 20  # optional

    def get_queryset(self):
        return (
            AirspaceWaiver.objects.filter(user=self.request.user)
            .exclude(conops_text__isnull=True)
            .exclude(conops_text__exact="")
            .order_by("-conops_generated_at", "-created_at")
        )


class WaiverListView(LoginRequiredMixin, ListView):
    """
    Shows all waivers for the logged-in user, regardless of CONOPS status.
    """
    model = AirspaceWaiver
    template_name = "airspace/waiver_list.html"
    context_object_name = "waivers"
    paginate_by = 20  # tweak or remove as you prefer

    def get_queryset(self):
        return (
            AirspaceWaiver.objects.filter(user=self.request.user)
            .order_by("-created_at")
        )
