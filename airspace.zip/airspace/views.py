from django.contrib import messages
import logging
logger = logging.getLogger(__name__)

from django.db.models import Sum
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.generic import ListView, TemplateView
from django.urls import reverse
from formtools.wizard.views import SessionWizardView


from .models import AirspaceWaiver, WaiverPlanning
from .services import generate_conops_text
from .utils import dms_to_decimal 
from .utils import generate_short_description
from flightlogs.models import FlightLog
from equipment.models import Equipment

from .forms import (
    AirspaceWaiverForm,
    AirspaceWaiverOverviewForm,
    AirspaceWaiverLocationForm,
    AirspaceWaiverDescriptionForm,
    WaiverPlanningForm,
)



from django.contrib import messages
import logging







class AirspacePortalView(LoginRequiredMixin, TemplateView):
    template_name = "airspace/airspace_portal.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        user = self.request.user

        # ---- Flight stats ----
        # FlightLog.pilot_in_command is a CharField with "First Last", not a FK
        full_name = f"{user.first_name} {user.last_name}".strip()

        flights = FlightLog.objects.filter(pilot_in_command__iexact=full_name)

        ctx["total_flights"] = flights.count()

        # Sum the air_time DurationField safely
        total_flight_time = flights.aggregate(total=Sum("air_time"))["total"]
        ctx["total_flight_time"] = total_flight_time  # can be None if no flights

        # ---- Equipment stats ----
        ctx["active_drones"] = Equipment.objects.filter(
            equipment_type="Drone",
            active=True,
        ).count()

        # ---- Waiver stats ----
        waivers = AirspaceWaiver.objects.filter(user=user)
        ctx["total_waivers"] = waivers.count()
        ctx["waivers_with_conops"] = waivers.exclude(
            conops_text__isnull=True
        ).exclude(conops_text="").count()
        ctx["upcoming_waivers"] = waivers.filter(
            end_date__gte=timezone.now().date()
        ).count()

        return ctx






@login_required
def airspace_waiver(request):
    """
    Simple landing/helper page for the airspace waiver helper.
    """
    return render(request, "airspace/airspace_waiver_helper.html")








class WaiverListView(LoginRequiredMixin, ListView):
    """
    Shows all waivers for the logged-in user, regardless of CONOPS status.
    """
    model = AirspaceWaiver
    template_name = "airspace/waiver_list.html"
    context_object_name = "waivers"
    paginate_by = 20  # tweak or remove as you prefer

    def get_queryset(self):
        return (
            AirspaceWaiver.objects.filter(user=self.request.user)
            .order_by("-created_at")
        )




@login_required
def waiver_wizard_new(request):
    if request.method == "POST":
        form = WaiverPlanningForm(request.POST, user=request.user)
        if form.is_valid():
            planning = form.save(commit=False)
            planning.user = request.user
            planning.save()
            messages.success(
                request,
                "Planning details saved. Continue to the FAA waiver application.",
            )
            url = reverse("airspace:waiver_form")
            return redirect(f"{url}?planning_id={planning.pk}")
    else:
        form = WaiverPlanningForm(user=request.user)

    # Build lightweight data for JS auto-fill (pilots)
    pilot_qs = form.fields["pilot_profile"].queryset
    pilot_profile_data = []
    for p in pilot_qs:
        total_seconds = p.flight_time_total() or 0
        hours_value = round(total_seconds / 3600.0, 1)
        pilot_profile_data.append(
            {
                "id": p.id,
                "first_name": p.user.first_name,
                "last_name": p.user.last_name,
                "license_number": getattr(p, "license_number", "") or "",
                "flight_hours": hours_value,
            }
        )

    # Build lightweight data for JS auto-fill (aircraft -> safety features)
    aircraft_qs = form.fields["aircraft"].queryset.select_related("drone_safety_profile")
    drone_safety_data = []
    for eq in aircraft_qs:
        profile = getattr(eq, "drone_safety_profile", None)
        if profile and profile.safety_features:
            drone_safety_data.append(
                {
                    "id": str(eq.pk),
                    "safety_features": profile.safety_features,
                }
            )

    context = {
        "form": form,
        "planning_mode": "new",
        "pilot_profile_data": pilot_profile_data,
        "drone_safety_data": drone_safety_data,
    }
    return render(request, "airspace/waiver_wizard_new.html", context)








@login_required
def waiver_wizard_edit(request, pk):
    waiver = get_object_or_404(AirspaceWaiver, pk=pk, user=request.user)
    planning, created = WaiverPlanning.objects.get_or_create(
        waiver=waiver,
        defaults={"user": request.user},
    )

    if request.method == "POST":
        form = WaiverPlanningForm(request.POST, instance=planning, user=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Planning details updated.")
            return redirect("airspace:waiver_edit", pk=waiver.pk)
    else:
        form = WaiverPlanningForm(instance=planning, user=request.user)

    pilot_qs = form.fields["pilot_profile"].queryset
    pilot_profile_data = []
    for p in pilot_qs:
        total_seconds = p.flight_time_total() or 0
        hours_value = round(total_seconds / 3600.0, 1)
        pilot_profile_data.append(
            {
                "id": p.id,
                "first_name": p.user.first_name,
                "last_name": p.user.last_name,
                "license_number": getattr(p, "license_number", "") or "",
                "flight_hours": hours_value,
            }
        )

    # Aircraft -> safety features data
    aircraft_qs = form.fields["aircraft"].queryset.select_related("drone_safety_profile")
    drone_safety_data = []
    for eq in aircraft_qs:
        profile = getattr(eq, "drone_safety_profile", None)
        if profile and profile.safety_features:
            drone_safety_data.append(
                {
                    "id": str(eq.pk),
                    "safety_features": profile.safety_features,
                }
            )

    context = {
        "form": form,
        "planning_mode": "edit",
        "waiver": waiver,
        "pilot_profile_data": pilot_profile_data,
        "drone_safety_data": drone_safety_data,
    }
    return render(request, "airspace/waiver_planning.html", context)

































# --- NOT USED AT THIS POINT. ------------------------------------


STEP_TITLES = {
    "overview": "Operation Overview",
    "description": "Mission Narrative & Existing Waivers",
    "location": "Location & Airspace Details",
}





class AirspaceWaiverDraftWizard(LoginRequiredMixin, SessionWizardView):
    """
    Multi-step wizard for creating an AirspaceWaiver draft.

    Steps:
      1) overview     – operation basics, timeframe, aircraft, AGL, etc.
      2) location     – coordinates, radius, airspace, nearest airport.
      3) description  – mission details helper questions, generated description,
                        and related-waiver info.
    """

    form_list = [
        ("overview", AirspaceWaiverOverviewForm),
        ("location", AirspaceWaiverLocationForm),
        ("description", AirspaceWaiverDescriptionForm),
    ]
    template_name = "airspace/waiver_wizard.html"

    # Used to render headings in the nav pills and page text
    step_titles = {
        "overview": "Operation Overview",
        "location": "Location & Airspace",
        "description": "Mission Details & Description",
    }

    # Helper-only fields from AirspaceWaiverDescriptionForm
    DESCRIPTION_HELPER_KEYS = [
        "mission_purpose",
        "operational_area",
        "altitude_profile",
        "aircraft_payload",
        "launch_staging",
        "crew_vlos",
        "safety_actions",
    ]

    # ------------------------------
    # Context helpers
    # ------------------------------

    def get_context_data(self, form, **kwargs):
        context = super().get_context_data(form=form, **kwargs)

        form_keys = list(self.get_form_list().keys())
        current_key = self.steps.current
        current_index = form_keys.index(current_key) + 1
        total_steps = len(form_keys)

        context.update(
            {
                "current_step_key": current_key,
                "current_step_number": current_index,
                "total_steps": total_steps,
                "progress_percent": int((current_index / total_steps) * 100),
                "step_titles": self.step_titles,
            }
        )

        # Optional: lightweight planning snapshot for the header
        context["planning_snapshot"] = self.build_planning_snapshot()

        return context

    def build_planning_snapshot(self):
        """
        Builds the small 'Planning snapshot' box shown at the top of the wizard.

        Pulls from:
          - overview step (aircraft)
          - PilotProfile for the logged-in user (if present)
        """
        snapshot = {}

        # From step 1 (overview)
        overview = self.get_cleaned_data_for_step("overview") or {}
        aircraft = overview.get("aircraft") or overview.get("aircraft_custom")
        if aircraft:
            snapshot["aircraft"] = str(aircraft)

        # From PilotProfile, if you have that model wired up
        user = self.request.user
        pilot_profile = getattr(user, "pilotprofile", None)

        if pilot_profile:
            snapshot["pilot"] = f"{user.first_name} {user.last_name}".strip() or user.username
            snapshot["pilot_cert"] = pilot_profile.license_number or ""
            try:
                # These methods may exist on your PilotProfile model
                snapshot["flight_hours"] = round(
                    (pilot_profile.flight_time_total() or 0) / 3600, 1
                )
            except Exception:
                # Fallback if flight_time_total isn't available
                snapshot["flight_hours"] = None

        # If you later track 107.39 status per user, you can add it here
        snapshot["oop_flag"] = False
        snapshot["oop_number"] = ""

        # Only return a dict if we have at least one meaningful value
        if any(snapshot.values()):
            return snapshot
        return None

    # ------------------------------
    # Description generation logic
    # ------------------------------

    def build_description_from_helpers(self, helper_data: dict) -> str:
        """
        Take the helper fields from the description step and assemble a
        concise Description of Operations paragraph.

        `helper_data` is expected to contain keys from DESCRIPTION_HELPER_KEYS.
        """
        parts = []

        mp = (helper_data.get("mission_purpose") or "").strip()
        if mp:
            parts.append(mp)

        area = (helper_data.get("operational_area") or "").strip()
        if area:
            parts.append(area)

        alt = (helper_data.get("altitude_profile") or "").strip()
        if alt:
            parts.append(alt)

        ac = (helper_data.get("aircraft_payload") or "").strip()
        if ac:
            parts.append(ac)

        launch = (helper_data.get("launch_staging") or "").strip()
        if launch:
            parts.append(launch)

        crew = (helper_data.get("crew_vlos") or "").strip()
        if crew:
            parts.append(crew)

        safety = (helper_data.get("safety_actions") or "").strip()
        if safety:
            parts.append(safety)

        return "  ".join(parts)

    def post(self, *args, **kwargs):
        """
        Intercepts the 'Generate Description' button on the description step.

        - Stays on the same step.
        - Builds `short_description` from the helper fields.
        - Re-renders the form with the generated text populated.
        """
        request = self.request
        current_step = self.steps.current

        if current_step == "description" and "generate_description" in request.POST:
            form = self.get_form(data=request.POST, files=request.FILES)

            # We don't care if short_description is currently empty; we only need
            # the raw helper values, which are present in form.data.
            prefix = form.prefix  # e.g. "description" or "wizard_description"
            data = request.POST.copy()

            helper_data = {}
            for key in self.DESCRIPTION_HELPER_KEYS:
                field_name = f"{prefix}-{key}"
                helper_data[key] = data.get(field_name, "")

            desc_text = self.build_description_from_helpers(helper_data)

            # Write the generated text into the short_description field
            short_desc_name = f"{prefix}-short_description"
            data[short_desc_name] = desc_text

            # Re-bind the form with updated data so the textarea shows the new text
            form = self.get_form(data=data, files=request.FILES)

            # Re-render the same step; do NOT advance the wizard
            return self.render(form)

        # Default wizard behavior for normal Continue / Back / Save
        return super().post(*args, **kwargs)

    # ------------------------------
    # Final save
    # ------------------------------

    def done(self, form_list, form_dict, **kwargs):
        """
        Combine cleaned data from all steps, drop helper-only fields,
        and create the AirspaceWaiver instance.
        """
        data = {}

        for step, form in form_dict.items():
            cleaned = form.cleaned_data.copy()

            # Remove helper-only fields from the description step so we don't
            # try to pass them to AirspaceWaiver.objects.create(...)
            if step == "description":
                for key in self.DESCRIPTION_HELPER_KEYS:
                    cleaned.pop(key, None)

            data.update(cleaned)

        waiver = AirspaceWaiver.objects.create(
            user=self.request.user,
            **data,
        )

        # Redirect or render a success page as you already do
        # (adjust the URL name to whatever you use in your app)
        from django.shortcuts import redirect
        return redirect("airspace:waiver_detail", pk=waiver.pk)










@login_required
def airspace_waiver_form(request):
    """
    Step 2: FAA waiver form.

    If a planning entry was created first, we accept a planning_id via
    querystring or POST and link that planning record to the newly-
    created waiver after successful save.

    After submission, the user is sent back to the Waiver List.
    """
    planning_id = request.GET.get("planning_id") or request.POST.get("planning_id")
    planning = None
    if planning_id:
        try:
            planning = WaiverPlanning.objects.get(pk=planning_id, user=request.user)
        except WaiverPlanning.DoesNotExist:
            planning = None

    if request.method == "POST":
        form = AirspaceWaiverForm(request.POST)
        if form.is_valid():
            waiver = form.save(commit=False)
            waiver.user = request.user
            waiver.save()  # computes decimal coords in model.save()

            # Attach planning to this waiver, if present and not already linked
            if planning and planning.waiver_id is None:
                planning.waiver = waiver
                planning.save(update_fields=["waiver"])

            messages.success(
                request,
                "Waiver draft saved. You can now generate a CONOPS from this data.",
            )
            return redirect("airspace:waiver_list")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = AirspaceWaiverForm()

    context = {
        "form": form,
        "planning_id": planning_id,
    }
    return render(request, "airspace/waiver_form_edit.html", context)





def airspace_waiver_edit(request, pk):
    """
    Edit an existing AirspaceWaiver.

    Supports two actions:
    - Normal save (Save / Save Waiver Draft)
    - Regenerate Brief Description of Operations from current form data
    """
    waiver = get_object_or_404(AirspaceWaiver, pk=pk, user=request.user)

    if request.method == "POST":
        form = AirspaceWaiverForm(request.POST, instance=waiver)

        # --- Regenerate button clicked ---
        if "regen_short_description" in request.POST:
            temp_waiver = waiver

            # Try to use the posted values if they validate; otherwise fall back
            if form.is_valid():
                temp_waiver = form.save(commit=False)

            # Generate description from whichever data we have in temp_waiver
            temp_waiver.short_description = generate_short_description(temp_waiver)

            # Rebuild a form bound to the updated temp_waiver so the textarea shows the new text
            form = AirspaceWaiverForm(instance=temp_waiver)

            messages.info(
                request,
                "Brief Description of Operations regenerated from the current waiver details.",
            )

            context = {
                "form": form,
                "waiver": waiver,
                "lat_decimal": waiver.lat_decimal,
                "lon_decimal": waiver.lon_decimal,
            }
            return render(request, "airspace/waiver_form_edit.html", context)

        # --- Normal save path ---
        if form.is_valid():
            form.save()
            messages.success(request, "Waiver updated successfully.")
            return redirect("airspace:waiver_list")
        else:
            # 🔍 TEMP: log exactly what failed
            logger.error("AirspaceWaiverForm errors: %s", form.errors)
            # or, if you prefer, in dev:
            print("AirspaceWaiverForm errors:", form.errors)

            messages.error(request, "Please correct the errors below.")
    else:
        form = AirspaceWaiverForm(instance=waiver)

    context = {
        "form": form,
        "waiver": waiver,
        "lat_decimal": waiver.lat_decimal,
        "lon_decimal": waiver.lon_decimal,
    }
    return render(request, "airspace/waiver_form_edit.html", context)






@login_required
def waiver_conops_view(request, pk):
    """
    Display a single waiver and allow generating / regenerating CONOPS text.
    """
    waiver = get_object_or_404(AirspaceWaiver, pk=pk, user=request.user)

    if request.method == "POST":
        try:
            conops = generate_conops_text(waiver)
            waiver.conops_text = conops
            waiver.conops_generated_at = timezone.now()
            waiver.save(update_fields=["conops_text", "conops_generated_at"])
            messages.success(request, "CONOPS generated successfully.")
            return redirect("airspace:waiver_conops", pk=waiver.pk)
        except Exception as e:
            messages.error(
                request,
                f"Something went wrong while generating the CONOPS: {e}",
            )

    context = {
        "waiver": waiver,
    }
    return render(request, "airspace/waiver_conops.html", context)




class ConopsListView(LoginRequiredMixin, ListView):
    """
    Shows only waivers that already have CONOPS text.
    """
    model = AirspaceWaiver
    template_name = "airspace/conops_list.html"
    context_object_name = "waivers"
    paginate_by = 20  # optional

    def get_queryset(self):
        return (
            AirspaceWaiver.objects.filter(user=self.request.user)
            .exclude(conops_text__isnull=True)
            .exclude(conops_text__exact="")
            .order_by("-conops_generated_at", "-created_at")
        )






class WaiverConopsSummaryView(LoginRequiredMixin, TemplateView):
    """
    Read-only page that summarizes the information included
    in the Waiver CONOPS generated by the AirSpace app.
    """
    template_name = "airspace/waiver_conops_summary.html"
    extra_context = {
        "page_title": "Waiver CONOPS Summary",
    }






