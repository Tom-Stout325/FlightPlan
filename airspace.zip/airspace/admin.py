# airspace/admin.py
from django.contrib import admin



